n = input()
while n:
	n -= 1
	a,b,c,d,n,m,r = map(int,raw_input().split())
